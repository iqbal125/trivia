import { Injectable } from '@nestjs/common';
import { Model, Types } from 'mongoose';
import { Question, QuestionDocument } from './schemas/question.schema';
import { InjectModel } from '@nestjs/mongoose';

@Injectable()
export class QuizService {
    constructor(
        @InjectModel(Question.name) private questionModel: Model<QuestionDocument>,
    ) { }

    async getCategories(): Promise<string[]> {
        const categories = await this.questionModel.distinct('category');
        return categories;
    }

    async getQuiz(category: string, difficulty: string, amount: number) {
        const questions = await this.questionModel.aggregate([
            { $match: { category, difficulty } },
            { $sample: { size: amount } },
        ]);

        return questions.map((q) => {
            const options = [...q.incorrect_answers, q.correct_answer].sort(() => Math.random() - 0.5);

            return {
                id: q._id.toString(),
                question: q.question,
                options,
            };
        });
    }


    async scoreQuiz(answers: { id: string; selected: string }[]) {
        const ids = answers.map((a) => new Types.ObjectId(a.id));

        const questions = await this.questionModel.find({ _id: { $in: ids } });

        let score = 0;

        const results = answers.map((ans) => {
            const question = questions.find(({ _id }) => (_id as string).toString() === ans.id);
            const isCorrect = question?.correct_answer === ans.selected;
            if (isCorrect) score += 1;

            return {
                id: ans.id,
                question: question?.question,
                selected: ans.selected,
                correct: question?.correct_answer,
                isCorrect,
            };
        });

        return { score, results };
    }


}
