import { Controller, Get, Post, Query } from '@nestjs/common';
import { QuizService } from './quiz.service';

import { Body } from '@nestjs/common';
import { ScoreQuizDto } from './dto/score-quiz.dto';

@Controller('quiz')
export class QuizController {
    constructor(private readonly quizService: QuizService) { }

    @Get('ping')
    getPing() {
        return { message: 'pong' };
    }

    @Get('categories')
    async getCategories() {
        return this.quizService.getCategories();
    }

    @Get('quiz')
    async getQuiz(
        @Query('category') category: string,
        @Query('difficulty') difficulty: string,
        @Query('amount') amount: string,
    ) {
        return this.quizService.getQuiz(category, difficulty, parseInt(amount || '5'));
    }

    @Post('score')
    scoreQuiz(@Body() body: ScoreQuizDto) {
        return this.quizService.scoreQuiz(body.answers);
    }


}
