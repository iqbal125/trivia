import { Test, TestingModule } from '@nestjs/testing';
import { QuizService } from '../quiz.service';
import { getModelToken } from '@nestjs/mongoose';
import { Question } from '../schemas/question.schema';
import { Model, Types } from 'mongoose';

describe('QuizService', () => {
  let service: QuizService;
  let mockModel: Partial<Record<keyof Model<any>, jest.Mock>>;

  beforeEach(async () => {
    mockModel = {
      distinct: jest.fn(),
      aggregate: jest.fn(),
      find: jest.fn(),
    };

    const module: TestingModule = await Test.createTestingModule({
      providers: [
        QuizService,
        {
          provide: getModelToken(Question.name),
          useValue: mockModel,
        },
      ],
    }).compile();

    service = module.get<QuizService>(QuizService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  describe('getCategories', () => {
    it('should return distinct categories', async () => {
      mockModel.distinct!.mockResolvedValue(['Film', 'Science']);
      const result = await service.getCategories();
      expect(mockModel.distinct).toHaveBeenCalledWith('category');
      expect(result).toEqual(['Film', 'Science']);
    });
  });

  describe('getQuiz', () => {
    it('should return shuffled quiz options', async () => {
      mockModel.aggregate!.mockResolvedValue([
        {
          _id: new Types.ObjectId(),
          question: 'What is 2 + 2?',
          correct_answer: '4',
          incorrect_answers: ['2', '3', '5'],
        },
      ]);

      const result = await service.getQuiz('math', 'easy', 1);
      expect(result[0]).toHaveProperty('id');
      expect(result[0]).toHaveProperty('question');
      expect(result[0].options.length).toBe(4);
      expect(result[0].options).toContain('4');
    });
  });

  describe('scoreQuiz', () => {
    it('should return score and results array', async () => {
      const id = new Types.ObjectId().toString();

      mockModel.find!.mockResolvedValue([
        {
          _id: new Types.ObjectId(id),
          question: 'What is the capital of France?',
          correct_answer: 'Paris',
        },
      ]);

      const result = await service.scoreQuiz([
        { id, selected: 'Paris' },
      ]);

      expect(result.score).toBe(1);
      expect(result.results[0]).toMatchObject({
        id,
        selected: 'Paris',
        correct: 'Paris',
        isCorrect: true,
      });
    });
  });
});

