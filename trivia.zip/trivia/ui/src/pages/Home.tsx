import React from 'react';
import CategorySelector from '../components/CategorySelector';
import DifficultySelector from '../components/DifficultySelector';
import AmountSelector from '../components/AmountSelector';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';
import { useSelector } from 'react-redux';
import type { RootState } from '../store';

const Home: React.FC = () => {
    const { category, difficulty } = useSelector((state: RootState) => state.quiz);
    const navigate = useNavigate();
    const canStart = category && difficulty;

    return (
        <div className="max-w-xl mx-auto p-6 space-y-6">
            <h1 className="text-2xl font-bold">Start a Quiz</h1>
            <CategorySelector />
            <DifficultySelector />
            <AmountSelector />
            <Button disabled={!canStart} onClick={() => navigate("/quiz")} className="bg-black text-white hover:bg-gray-800">
                Start Quiz
            </Button>

        </div>
    );
};

export default Home;

