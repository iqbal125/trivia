import React from 'react';
import { useDispatch } from 'react-redux';
import { setAnswer } from '../store/quizSlice';

type Props = {
    question: string;
    answers: string[];
    index: number;
};

const QuestionCard: React.FC<Props> = ({ question, answers, index }) => {
    const dispatch = useDispatch();

    return (
        <div>
            <h4 dangerouslySetInnerHTML={{ __html: question }} />
            {answers.map((ans) => (
                <label key={ans}>
                    <input
                        type="radio"
                        name={`question-${index}`}
                        value={ans}
                        onChange={() => dispatch(setAnswer({ questionIndex: index, answer: ans }))}
                    />
                    <span dangerouslySetInnerHTML={{ __html: ans }} />
                </label>
            ))}
        </div>
    );
};

export default QuestionCard;
