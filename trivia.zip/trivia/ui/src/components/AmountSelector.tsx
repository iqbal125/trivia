import React from 'react';
import { useDispatch } from 'react-redux';
import { setAmount } from '../store/quizSlice';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';

const AmountSelector: React.FC = () => {
    const dispatch = useDispatch();

    return (
        <div className="space-y-1">
            <Label>Number of Questions</Label>
            <Input
                type="number"
                defaultValue={5}
                min={1}
                max={10}
                onChange={(e) => dispatch(setAmount(Number(e.target.value)))}
            />
        </div>
    );
};

export default AmountSelector;
