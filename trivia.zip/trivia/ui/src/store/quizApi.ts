import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react';

export const quizApi = createApi({
    reducerPath: 'quizApi',
    baseQuery: fetchBaseQuery({ baseUrl: 'http://localhost:3000/quiz' }),
    endpoints: (builder) => ({
        getCategories: builder.query<string[], void>({
            query: () => '/categories',
        }),
        getQuiz: builder.query<any[], { category: string; difficulty: string; amount: number }>({
            query: ({ category, difficulty, amount }) =>
                `/quiz?category=${encodeURIComponent(category)}&difficulty=${difficulty}&amount=${amount}`,
        }),
        submitQuiz: builder.mutation<
            { score: number; results: any[] },
            { answers: { id: string; selected: string }[] }
        >({
            query: (body) => ({
                url: '/score',
                method: 'POST',
                body,
            }),
        }),
    }),
});

export const { useGetCategoriesQuery, useGetQuizQuery, useSubmitQuizMutation } = quizApi;
